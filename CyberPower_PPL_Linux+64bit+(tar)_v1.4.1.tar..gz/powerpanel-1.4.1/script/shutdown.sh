#!/bin/sh

shutdown -h now
